const infoBox = document.getElementById('infoBox');
const infoHeading = document.getElementById('infoHeading');
const infoText = document.getElementById('infoText');
const closeLink = document.getElementById('closeLink');

const descriptions = [
  {
    caption: "Siamese Cat",
    info: "Siamese cats are vocal and social, with striking blue eyes and a sleek, short coat. They form strong bonds with their owners. Origin: Thailand."
  },
  {
    caption: "Maine Coon Cat",
    info: "Maine Coons are large, friendly cats with tufted ears and thick fur. Origin: United States."
  },
  {
    caption: "Persian Cat",
    info: "Persian cats are known for their long hair, flat faces, and calm personality. Origin: Iran (Persia)."
  },
  {
    caption: "Bengal Cat",
    info: "Bengals are energetic, with a wild appearance and striking spotted coat. Origin: Bengal region of India and Bangladesh."
  },
  {
    caption: "Ragdoll Cat",
    info: "Ragdolls are affectionate and often go limp when held, hence the name. Origin: United States."
  },
  {
    caption: "Scottish Fold Cat",
    info: "Scottish Folds have unique folded ears and a sweet, gentle temperament. Origin: Scotland."
  },
  {
    caption: "Sphynx Cat",
    info: "Sphynx cats are hairless and love warmth and attention. Origin: Canada."
  },
  {
    caption: "Abyssinian Cat",
    info: "Abyssinians are active cats with ticked coats and are one of the oldest breeds. Origin: Possibly Ethiopia (Abyssinia)."
  }
];

document.querySelectorAll('.description').forEach(desc => {
    desc.addEventListener('click', (event) => {
      const idx = desc.getAttribute('data-index');
      const rect = desc.getBoundingClientRect();
  
      // Set content
      infoHeading.textContent = descriptions[idx].caption;
      infoText.textContent = descriptions[idx].info;
  
      // Position info box near clicked image
      infoBox.style.top = `${window.scrollY + rect.top - infoBox.offsetHeight - 10}px`;
      infoBox.style.left = `${window.scrollX + rect.left}px`;
      infoBox.style.visibility = 'visible';
    });
  });
  

closeLink.addEventListener('click', e => {
  e.preventDefault();
  infoBox.style.visibility = 'hidden';
});
